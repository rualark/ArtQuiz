<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  echo "Hello! You can contact me by email: rualark at gmail.com";
?>