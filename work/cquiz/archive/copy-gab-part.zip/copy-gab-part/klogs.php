<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  secure_variable("cab");
  secure_variable("u_id");
  secure_variable("filter");

  if (!isset($cab)) $cab = "";
  
  show_user_klogs($u_id, $cab);
  stop_time();
?>