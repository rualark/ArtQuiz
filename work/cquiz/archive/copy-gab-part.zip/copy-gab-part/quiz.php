<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  echo "<body onload='document.getElementById(\"sel1\").focus(); document.getElementById(\"sel1\").checked = true; window.scroll(0, 130); play_correct();'>";
  $no_title = 1;
  if (!isset($bblock)) include "menu.php";

  secure_variable("c_id");
  secure_variable("bblock");
  secure_variable("t_id");
  secure_variable("b_id");
  secure_variable("b_comment");

  start_time();
  if ($bblock == 2) {
    if (!isset($t_id)) $t_id = $us[t_id];
    if (!isset($b_id)) $b_id = $us[b_id];
    $r=mysql_query("INSERT INTO cc_bblocks VALUES('$b_id','$t_id','','$us[u_id]',NOW(),0,'$b_comment')");
    echo "<font color=red>Broken track reported!</font><br>";
    exit;
  }

  if ($bblock == 1) {
    echo "Please comment, what is bad with this particular track (for example, wrong composer or no sound or noise or anything else). Also, write which block is bad if you can:<br>";
    echo "<form action=quiz.php method=get>";
    echo "<input type=hidden name=bblock value=2>";
    if (isset($t_id)) echo "<input type=hidden name=t_id value='$t_id'>";
    if (isset($b_id)) echo "<input type=hidden name=b_id value='$b_id'>";
    echo "<input type=text size=80 name=b_comment><br>";
    echo "<input type=submit> ";
    echo "</form>";
    exit;
  }
  
  echo "<b id=hl>".$level_name[$us[u_level]]." ".($us[r_total]+1).". Please listen to the piece of music and guess the composer:</b><br>";
  echo "<table border=0><tr><td bgcolor=black>
    <table cellpadding=10 border=0 cellspacing=1>";
  echo "<tr>";
  echo "<td bgcolor=white align=left valign=top>";
  $ncust = substr_count($us[u_ca], "X");
  if (($us[u_level] == $level_cust) && ($ncust < 2)) 
    die("You have to select at least two composers to use Custom mode!");
  if (isset($c_id)) {
    $t_id = $us[t_id];
    $b_id = $us[b_id];
    $start = $us[u_start];
    if ($t_id == 0) die("This question is finished. Please go to the <a id=sel1 href=quiz.php?nc=".microtime(TRUE).">next question</a>.");
    load_track($t_id);
    // Remove links
    if ($play_symlinks>0) if (file_exists("ln/$us[u_id]")) {
      $max_blocks = floor($ts[t_len]/$block_len)+1;
      for ($i=1; $i<=$max_blocks+2; $i++) {
        $link = block_url($t_id, $i, 1);
        //echo block_url($t_id, $i)." $link<br>";
        if (is_link($link)) unlink($link);
      }
      rmdir("ln/$us[u_id]");
    }
    $ca1 = load_composer($c_id);
    $ca2 = load_composer($ts[c_id]);
    $cent = $ca1[c_start] - $ca2[c_start];
    if ($ca2[cpic_url] != "") echo "<img width=200 title='$ca2[c_name]' hspace=2 vspace=2 align=right src='$ca2[cpic_url]'>";
    echo "You selected: <a target=_blank href=".comp_link($c_id).">";
    if ($c_id != $ts[c_id]) echo "<font color=grey>";
    echo "$ca1[c_name]</font></a> [$ca1[c_years]] $ca1[c_country] ($ca1[p_name])<br>";
    if ($c_id == $ts[c_id]) {
      $cor_st = "c$ca2[c_id]";
      echo "<title>CQuiz - Guess the composer (quiz) Answer Correct</title>";
      echo "<font color=green size=6><b>Correct!</b></font><br>";
      $ok=1;
      //if (($us[u_id] == 27) && (mt_rand(0, 100)<10)) $cor_st = "Day poceluyu";
    } else {
      $cor_st = "w$ca2[c_id]";
      echo "<title>CQuiz - Guess the composer (quiz) Answer Wrong</title>";
      echo "<font color=red size=5><b>Wrong. ";
      if (abs($cent)>70) echo "$cent years difference. ";
      $wrong2 = 0;
      if ($ca1[p_name] != $ca2[p_name]) {
        echo "Wrong period. ";
        $wrong2 = 1;
      }
      echo "</b></font><br>";
      echo "Correct answer: <a target=_blank href=../classclass/am.php?u_id=$us[u_id]&c_id=$ca2[c_id]>$ca2[c_name]</a> [$ca2[c_years]] $ca2[c_country] ($ca2[p_name])<br>";
      $ok=0;
      //if (($us[u_id] == 27) && (mt_rand(0, 100)<10)) $cor_st = "Fikgnaa";
    }
    if ($us[u_speechvol] == 1) {
      $path = "voice/correct-30.mp3";
      if ($cor_st[0] == 'w') $path = "voice/wrong-25.mp3";
      play_file("play_correct", $path);
    } elseif ($us[u_speechvol] > 1) {
      text2speech("play_correct", $cor_st);
    }
    $r1 = log_game($b_id, time()-$start, $c_id, $ok, $wrong2, $cent);
    echo "<a id=sel1 href=quiz.php?nc=".microtime(TRUE)."#hl>Go to next question >>>>>>></a>";
    if ($uname == "rualark") echo " <img src='images/gp_back.png' align=center height=20>";
    echo "<br>";
    echo "<font color=black><b><br>Track name: $ts[t_folder]/$ts[t_name]";
    echo "<br>";
    echo str_replace("\n", "<br>", meta_conv($ts[t_meta]));
    echo "<br>";
    echo "<br></b></font>";
    $q5 = "SELECT count(*) as cnt,avg(l_ok) as cor FROM cc_qlog WHERE u_id='$us[u_id]' AND t_id=$t_id AND l_time > '$tracks_start'";
    $r5 = mysql_query($q5);
    echo mysql_error();
    $w5 = mysql_fetch_assoc($r5);
    $q6 = "SELECT count(*) as cnt,avg(l_ok) as cor FROM cc_qlog WHERE u_id='$us[u_id]' AND t_id=$t_id AND b_id=$b_id AND l_time > '$tracks_start'";
    $r6 = mysql_query($q6);
    echo mysql_error();
    $w6 = mysql_fetch_assoc($r6);
    echo "You hear this track: <a href=ptracks.php?t_id=$t_id&b_id=$b_id>$w5[cnt] times</a> (".round($w5[cor]*100)."% correct)";
    if ($us[u_oneblock]) echo " and this 1-minute block <b>$w6[cnt] times</b> (".round($w6[cor]*100)."% correct).";
    echo "<br>";
    show_played_composer($ts[c_id]);
    if ($us[u_level] == $level_cust) {
      $r11 = mysql_query("SELECT * FROM cc_isles LEFT JOIN cc_users USING (u_id) WHERE i_cab=x'$us[cab]'");
      $w11 = mysql_fetch_assoc($r11);
      echo "You get ";
      if ($r1 >= $w11[r1_max]) echo "<font color=green>";
      echo "<b>$r1</b></font> rating for this answer. Your total rating is <a href=graph.php?level=$us[u_level]&cab=$us[cab]>".round($us[r_r1])."</a>. ";
      if ($us[u_id] == $w11[u_id]) {
        echo "You are the king ";
        echo show_crown($w11[r_total], $w11[u_id2], $w11[i_unum]);
        echo " of this island.";
      }
      elseif ($w11[r1_max]==0) echo "This island has no king yet.";
      else {
        echo "This island king <b>$w11[u_name]</b> ";
        echo show_crown($w11[r_total], $w11[u_id2], $w11[i_unum]);
        echo " has rating <b>$w11[r1_max]</b>.";
      }
    } else {
      echo "You get <b>$r1</b> rating for this answer. Your total rating is <b>".round($us[r_r1])."</b>. ";
    }
    echo "<br>";
    echo "Track duration: ".date('i:s', $ts[t_len])."<br>";
    if ($us[u_oneblock] == 1) echo "Minute selected for quiz: $b_id<br>";
    echo "Time to answer: ".date('i:s', time()-$start)."<br>";
    $oneblock = 0;
    echo "<br>";
    show_user_stat();
  } else {
    echo "<title>CQuiz - Guess the composer (quiz) Question</title>";
    if ($us[u_speechvol] > 1) 
      text2speech("play_correct", $us[r_total]+1);
    //echo "t_id $us[t_id]";
    if ($us[t_id] != 0) {
      $t_id = $us[t_id];
      load_track($t_id);
      $b_id = $us[b_id];
      $start = $us[u_start];
      echo "<font color=red>Unfinished question detected. Please answer the question to continue.</font>";
    } else {
      // Select track
      /*
      $t_id = choose_track();
      load_track($t_id);
      $b_id = choose_block();
      */
      $b_id = choose_block_new();
      load_track($t_id);
      if (($t_id == 0) || ($b_id == 0)) {
        die("There was a problem selecting track for your question. 
          The problem has been logged. 
          Please refresh the page.<br><br>
          If refreshing does not help, please try changing the options in your preferences.
          Thank you for your patience!");
      }
      //echo "Selected block $b_id<br>";
      $start = time();
      // Create links
      if ($play_symlinks>0) {
        if (!file_exists("ln/$us[u_id]")) mkdir("ln/$us[u_id]");
        if ($us[u_oneblock]) {
          $link = block_url($t_id, 1, 1);
          if (is_link($link)) unlink($link);
          symlink("../../".block_url($t_id, $b_id), $link);
          if (!is_link($link)) symlink("../../".block_url($t_id, $b_id), $link);
          if (!is_link($link)) symlink("../../".block_url($t_id, $b_id), $link);
        } else {
          $max_blocks = floor($ts[t_len]/$block_len)+1;
          for ($i=1; $i<=$max_blocks; $i++) {
            $link = block_url($t_id, $i, 1);
            //echo block_url($t_id, $i)." $link<br>";
            if (is_link($link)) unlink($link);
            symlink("../../".block_url($t_id, $i), $link);
            if (!is_link($link)) symlink("../../".block_url($t_id, $i), $link);
            if (!is_link($link)) symlink("../../".block_url($t_id, $i), $link);
          }
        }
      }
    }
    echo "<script>";
    echo "function startTime() {\n";
    echo "var today=new Date();\n";
    echo "var ddif = new Date(today.getTime() - $start*1000);\n";
    echo "var h=ddif.getHours();\n";
    echo "var m=ddif.getMinutes();\n";
    echo "var s=ddif.getSeconds();\n";
    echo "m=checkTime(m);\n";
    echo "s=checkTime(s);\n";
    echo "document.getElementById('timediv').innerHTML=h+\":\"+m+\":\"+s;\n";
    echo "t=setTimeout(function(){startTime()},500);\n";
    echo "}\n";

    echo "function checkTime(i) {\n";
    echo "if (i<10) {\n";
    echo "  i=\"0\" + i;\n";
    echo "}\n";
    echo "return i;\n";
    echo "}\n";
    echo "</script>";
    echo "<form id=qform action=quiz.php method=get>";
    //echo "<input type=hidden name=t_id value=$ts[t_id]>";
    //echo "<input type=hidden name=b_id value=$b_id>";
    echo "<input type=hidden name=ac value=$start>";
    show_composers();
    echo "</form>";
    if ($t_id > 0) {
      $oneblock = $us[u_oneblock];
      $us[t_id] = $t_id;
      $us[b_id] = $b_id;
      $us[u_start] = $start;
      save_user();
    }
  }
  
  echo "<td bgcolor=white align=left valign=top>";
  $b_id2 = $b_id;
  if (($us[u_oneblock]) && ($play_symlinks>0)) $b_id2 = 1;
  show_player($t_id, $b_id2, isset($c_id) ? 0 : $us[u_oneblock], 
    isset($c_id) ? 0 : $play_symlinks, isset($c_id) ? 0 : 1, $b_id);
  //if ((!isset($c_id)) && ($us[u_oneblock]) && ($b_id == 1)) echo "It is the first minute of track. ";
  /*
  $xmlurl = "qlist.php?u_id=$us[u_id]-$us[u_start]";
  if (isset($c_id)) $xmlurl = "qlist.php?t_id=$t_id";
  echo "<div><object type='application/x-shockwave-flash' data='dewplayer/dewplayer-playlist-cover.swf' width='240' height='220' id='dewplayer' name='dewplayer'>";
  echo "<param name='wmode' value='transparent' />";
  echo "<param name='movie' value='dewplayer/dewplayer-playlist-cover.swf' />";
  echo "<param name='flashvars' value='";
  //if (!isset($c_id)) echo "autoplay=1&";
  //echo "randomplay=1&";
  echo "showtime=1&autoreplay=true&javascript=on&";
  echo "xml=$xmlurl' />";
  echo "</object></div>";
  */
  //echo "<button valign=center onclick=\"go(2);\"><img style='vertical-align: middle' border=0 src=images/play.gif></button>";
  echo "<a target=_blank href=".block_url($t_id, $b_id2, isset($c_id) ? 0 : $play_symlinks)."?$us[u_start]>Alternative link</a><br>";
  echo "<br><a onclick='return confirm(\"Please confirm, that you want to report this track as broken. Report will be sent to site administration. You should only report tracks as broken if you do not hear any sound or if the sound is garbled. PLEASE NOTE THAT TO PROTECT PLAYERS FROM CHEATING, YOU WILL HAVE TO ANSWER THIS QUESTION ANYWAY. Please select any answer after reporting broken track. Thank you for your patience!\");' target=_blank href=quiz.php?ac=$start&bblock=1";
  if (isset($c_id)) echo "&c_id=$c_id&t_id=$t_id&b_id=$b_id";
  echo "><font color=red>Report broken track</font></a>";
  //echo "<a href=\"$xmlurl\">Qlist</a>";
  echo "<br><div id=timediv></div>";
  echo "</table>";
  echo "</table>";
  //echo "$ts[c_name]";
 
  echo "<br>If you start a new question, answer it before leaving the site to save your rating.";
  stop_time();
?>