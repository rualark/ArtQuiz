<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  secure_variable("cab");
  secure_variable("u_id");

  if (!isset($cab)) $cab = "";
  
  show_user_logs(-1, $cab);
  stop_time();
?>