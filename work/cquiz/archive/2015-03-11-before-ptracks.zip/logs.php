<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  secure_variable("cab");
  secure_variable("u_id");

  if (!isset($cab)) $cab = "";
  
  echo "<p align=right>";
  echo "<a href=forum.php>Last comments</a> | ";
  echo "<a href=plogs.php?cab=$cab>Last games</a> | ";
  echo "<a href=klogs.php>Island news</a> | ";
  echo "<p>";
  show_user_logs(-1, $cab);
  stop_time();
?>