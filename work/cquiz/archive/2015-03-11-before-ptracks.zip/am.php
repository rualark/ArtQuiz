<?
  if (isset($_GET['amg_id'])) $amg_id=$_GET['amg_id'];
  if (isset($_GET['c_id'])) $c_id=$_GET['c_id'];
  if (isset($_GET['t_id'])) $t_id=$_GET['t_id'];
  if (isset($_GET['sort'])) $sort=$_GET['sort'];
  $perc_min = 3;
  $perc_max = 5;

  include "analytics.php";
  include "mysql.php";
  include "style.php";
  include "cclib.php";
  include "qlib.php";
  include "menu.php";
  include "auth.php";
  
  start_time();
  
  function show_mysql_report_error() {
    echo "<font color=red>".mysql_report_error()."</font><br/>";
  }
  
  //echo "<title>ClassClass - classical music classification</title>";
  //echo "<center><a href=am.php>Genres</a> | <a href=amc.php>Composers</a> | <a href=ams.php>Search</a></center>";
  $cond_c = "AND c_id='$c_id'";
  
  echo "<center><b>";
  $r = mysql_query("SELECT c_desc,c_group,c_caid,c_amid,c_country,c_name3,c_years,count(*),c_name4 as cnt FROM cc_works LEFT JOIN cc_composers USING (c_id) WHERE c_id='$c_id'");
  echo mysql_report_error();
  $w = mysql_fetch_array($r);
  if ($w[c_name] == "") {
    $r = mysql_query("SELECT * FROM cc_composers WHERE c_id='$c_id'");
    $w = mysql_fetch_array($r);
  }
  $wc = $w;
  echo "$w[c_name3] ";
  echo "<a target=_blank href=\"http://en.wikipedia.org/w/index.php?search=$w[c_name3]\"><img height=20 border=0 src=i/wikipedia.jpg></a> ";
  echo "<a target=_blank href=\"http://youtube.com/results?search_query=$w[c_name3]\"><img height=20 border=0 src=i/youtube.png></a> ";
  echo "<a target=_blank href='http://www.google.ru/search?q=$w[c_name3]'><img height=20 border=0 src=i/google.png></a> ";
  echo "<a target=_blank href='http://www.google.ru/search?q=mfiles $w[c_name3]'><img height=20 border=0 src=i/mf.png></a> ";
  echo "<a target=_blank href='http://www.google.ru/search?q=site:imslp.org $w[c_name3]'><img height=20 border=0 src=i/imslp150.jpg></a> ";
  echo "<a target=_blank href=\"http://www.allmusic.com/artist/$w[c_amid]\"><img height=20 border=0 src=i/allmusic.png></a> ";
  echo "<a target=_blank href=\"http://www.classicalarchives.com/composer/$w[c_caid].html\"><img height=20 border=0 src=i/classicalarchives.jpg></a> ";
  echo "$w[c_country] [$w[c_years]]";
  echo "</b><br>";
  if (strlen($w[c_group])>1) echo "<b>Group:</b> $w[c_group]<br>";
  if (strlen($w[c_desc])>1) echo "<b>Short description:</b> $w[c_desc]<br>";
  echo "</center>";
  
  // Show tracks
  if ($u_id>0) $us[u_id] = $u_id;
  if ($us[u_id]>0) {
    show_played_composer($c_id);
    echo " Played blocks map: <br><img src='../cquiz/png-cblocks.php?u_id=$us[u_id]&c_id=$c_id'>";
  }
  echo "<br>";
  echo "<table><tr><td valign=top>";
  if (is_file("cpic/$w[c_id].jpg")) echo "<img width=200 src=cpic/$w[c_id].jpg align=right>";
  $q = "SELECT * FROM cc_ctracks LEFT JOIN cc_composers USING (c_id) LEFT JOIN cc_tgroups ON (cc_tgroups.tg_id=cc_ctracks.tg_id) WHERE t_bad=0 $cond_c";
  $r = mysql_query($q);
  show_mysql_report_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w=mysql_fetch_array($r);
    $wa[$i] = $w;
    $p1 = strpos($w[t_folder], "/");
    $fld = substr($w[t_folder], $p1+1);
    $fld .= "/";
    if ($p1 == 0) $fld = "";
    $fname = $w[t_name];
    $fname = str_replace(".mp3", "", $fname);
    if ($w[tg_id]>0) echo "<img title='$w[tg_name]' height=15 src=../cquiz/images/tg$w[tg_id].png> ";
    echo "<a href='../cquiz/ptracks.php?t_id=$w[t_id]'>$fld$fname</a> (".gmdate('H:i:s', $w[t_len]).")";
    if ($i_am_admin) if ($w[t_comment] != "") echo " <img title=\"".stripslashes($w[t_comment])."\" src=images/edit.png height=17>";
    echo " <a href=# onclick='myPlaylist.select($i); $(\"#jquery_jplayer_1\").jPlayer(\"play\"); return false; '><img src=images/play_g.gif height=16></a>";
    echo "<br>\n";
  }
  echo "<br><b>Last comments for this composer:</b> ";
  show_forum("", 100, 700, 0, $wc[c_name4]);
  echo "Showing 100 last comments";
  echo "<td valign=top>";
  show_player_i($wa);
  echo "</table>";
  stop_time();
?>