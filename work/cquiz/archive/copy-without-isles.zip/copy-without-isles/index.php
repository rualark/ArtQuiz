<?
  $no_menu=1;
  include "qlib.php";
  include "style.php";
  include "menu.php";
  
  echo "<br>";
  echo "<a href=reg.php><font size=6>Register new user</font></a><br><br>";
  echo "or<br><br>";
  echo "<a href=stats.php>Login</font></a><br><br>";
  show_help();
?>