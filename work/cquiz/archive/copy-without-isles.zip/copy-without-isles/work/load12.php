<?
  include "mysql.php";
  
  $q = "SELECT *,count(t_id) as cnt,sum(cc_ctracks.t_len) as tln FROM cc_composers LEFT JOIN cc_periods USING (p_name) LEFT JOIN cc_ctracks ON (cc_composers.c_id=cc_ctracks.c_id) WHERE c_folder != '' GROUP BY cc_ctracks.c_id";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  $p_name = "";
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_array($r);
    $r2 = mysql_query("UPDATE cc_composers SET c_len=$w[tln],t_count=$w[cnt] WHERE c_id=$w[c_id]");
  }
?>