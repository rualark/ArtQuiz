<?
mysql_connect("localhost", "cactiuser", "yifan");
//echo mysql_error();
mysql_select_db("amusic");
//echo mysql_error();
?>