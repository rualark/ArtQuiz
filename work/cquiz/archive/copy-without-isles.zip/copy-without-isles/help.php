<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  show_help();
?>