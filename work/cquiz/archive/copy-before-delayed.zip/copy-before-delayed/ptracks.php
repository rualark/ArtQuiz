<?
  //header('Content-Type: text/html; charset=cp1251');
  include "qlib.php";
  include "auth.php";
  include "style.php";
  echo "<body onload='play_correct();'>";

  include "menu.php";
  //mysql_set_charset("utf8");
  
  secure_variable("u_id");
  secure_variable("t_id");
  secure_variable("b_id");
  secure_variable("sort");
  
  start_time();
  
  if ($u_id>0) load_user($u_id);
  else $u_id = $us[u_id];
  if (!isset($b_id)) $b_id=1;

  if (isset($t_id)) {
    load_track($t_id);
    //text2speech("play_correct", "Correct. ".str_replace("'", "", iconv("UTF-8", "cp1251//TRANSLIT", $ts[c_name3])));
    echo "<table border=1 cellpadding=5>";
    echo "<tr>";
    echo "<td valign=top align=left>";
    echo "<b>Statistics for track $ts[t_name]</b> since $tracks_start<br><br>";
    echo "Composer: <a target=_blank href=../classclass/am.php?u_id=$us[u_id]&c_id=$ts[c_id]>$ts[c_name]</a> [$ts[c_years]] $ts[c_country] ($ts[p_name])<br>";
    echo "Group: ";
    if ($ts[tg_id]>0) echo "<img title='$ts[tg_name]' height=15 src=../cquiz/images/tg$ts[tg_id].png> ";
    echo "<a title='$ts[tg_comment]\n$ts[tg_tracks] tracks, $ts[tg_hours] hours, $ts[tg_cnum] composers";
    echo "' href='tgroups.php?tg_id=$ts[tg_id]'>";
    echo "$ts[tg_name]</font></a> ";
    if ($ts[tg_comment] != "") echo "($ts[tg_comment])";
    echo "<br>";
    echo "Track duration: ".date('i:s', $ts[t_len])."<br>";
    echo "<br>";
    if ($ts[t_bad]>0) {
      echo "<font color=red><b>This track is marked bad. It will not take place in the game and can be removed from database later. Tracks are marked bad if they are duplicates or if they have bad quality.";
      echo "<br>";
    }
    $fld = $ts[t_folder];
    if (strpos($fld, "/")>0) $fld = substr($fld, strpos($fld, "/")+1);
    echo "<font color=black><b><br>".str_replace("/", " / ", "$fld/".str_replace(".mp3", "", $ts[t_name]));
    //echo "<p title=\"".meta_conv($ts[t_meta])."\">".meta_conv($ts[t_meta2]);
    echo "<br>".str_replace("\n", "<br>", meta_conv($ts[t_meta]))."<br>";
    /*
    $ea = mb_list_encodings();
    for ($i=0; $i<count($ea); $i++) {
      echo str_replace("\n", "<br>", meta_conv($ts[t_meta]))."<br>";
    }
    */
    echo "<br>";
    echo "<td valign=top align=left>";
    $xmlurl = "qlist.php?t_id=$t_id";
    /*
    echo "<div><object type='application/x-shockwave-flash' data='dewplayer/dewplayer-playlist-cover.swf' width='240' height='200' id='dewplayer' name='dewplayer'>";
    echo "<param name='wmode' value='transparent' />";
    echo "<param name='movie' value='dewplayer/dewplayer-playlist-cover.swf' />";
    echo "<param name='flashvars' value='";
    //echo "autoplay=1&";
    echo "showtime=1&autoreplay=true&javascript=on&";
    echo "xml=$xmlurl' />";
    echo "</object></div>";*/
    show_player($t_id, 0, 0, 0, 0, $b_id);
    echo "<a target=_blank href=".block_url($t_id, 1).">Alternative link</a><br>";
    echo "<a onclick='return confirm(\"Please confirm, that you want to report this track as broken. Report will be sent to site administration. You should only report tracks as broken if you do not hear any sound or if the sound is garbled. PLEASE NOTE THAT TO PROTECT PLAYERS FROM CHEATING, YOU WILL HAVE TO ANSWER THIS QUESTION ANYWAY. Please select any answer after reporting broken track. Thank you for your patience!\");' target=_blank href=quiz.php?ac=$start&bblock=1";
    echo "&c_id=$c_id&t_id=$t_id&b_id=$b_id";
    echo "><font color=red>Report broken track</font></a>";
    echo "</table>";
    echo "<br>";
    $filter_t_id = $t_id;
    show_user_logs($u_id);
    stop_time();
    die();
  }
  
  $q = "SELECT count(DISTINCT t_id) as cnt FROM cc_qlog 
    WHERE u_id='$us[u_id]' AND UNIX_TIMESTAMP(cc_qlog.l_time) > UNIX_TIMESTAMP('$tracks_start')";
  $r = mysql_query($q);
  echo mysql_error();
  $w = mysql_fetch_assoc($r);
  $q2 = "SELECT count(DISTINCT (t_id*1000+b_id)) as cnt FROM cc_qlog 
    WHERE u_id='$us[u_id]' AND UNIX_TIMESTAMP(cc_qlog.l_time) > UNIX_TIMESTAMP('$tracks_start')";
  $r2 = mysql_query($q2);
  echo mysql_error();
  $w2 = mysql_fetch_assoc($r2);
  echo "User $us[u_name] heard $w[cnt] of $current_t_count tracks and 
    $w2[cnt] of $current_b_count 1-minute blocks (since $tracks_start)<br><br>";
  echo "<b>Problem tracks for user $us[u_name] (since $tracks_start):</b><br>";
  echo "<table border=1>";
  echo "<tr>";
  echo "<th><a href='ptracks.php?sort=c_name,correct'>Composer</th>";
  echo "<th><a href='ptracks.php?sort=t_name'>Track</th>";
  echo "<th><a href='ptracks.php?sort=correct,cnt DESC'>Correct</th>";
  echo "<th><a href='ptracks.php?sort=cnt desc'>Asked</th>";
  echo "<th><a href='ptracks.php?sort=wrong2 desc'>Wrong period</th>";
  echo "<th><a href='ptracks.php?sort=sec desc'>Think time</th>";
  echo "<th><a href='ptracks.php?sort=acent desc'>Abs. years error</th>";
  echo "<th><a href='ptracks.php?sort=cent desc'>Years error</th>";
  echo "</tr>";

  $order = "correct,cnt DESC";
  if (isset($sort)) $order = $sort;
  //$q = "SELECT *,count(t_id) as cnt,sum(c_len) as tln FROM cc_composers LEFT JOIN cc_periods USING (p_name) LEFT JOIN cc_ctracks ON (cc_composers.c_id=cc_ctracks.c_id) WHERE c_folder != '' GROUP BY cc_ctracks.c_id ORDER BY $order";
  $q = "SELECT *,avg(l_r1) as r1,sum(l_ok)/count(l_id) as correct,
    count(l_id) as cnt,avg(l_sec) as sec,
    sum(l_wrong2)/count(l_id) as wrong2,avg(abs(l_cent)) as acent,avg(l_cent) as cent 
    FROM cc_qlog 
    LEFT JOIN cc_ctracks USING (t_id) 
    LEFT JOIN cc_composers ON (cc_composers.c_id=cc_qlog.c_id)
    WHERE UNIX_TIMESTAMP(cc_qlog.l_time) > UNIX_TIMESTAMP('$tracks_start') AND cc_qlog.u_id='$u_id'
    GROUP BY cc_qlog.t_id 
    HAVING cnt>1 AND correct<1
    ORDER BY $order
    LIMIT $max_ptracks";
  //echo $q;
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  if ($n == 0) die("There was not a single track asked at least two times, that was answered wrong.");
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_array($r);
    echo "<tr>";
    echo "<td><a href=".comp_link($w[c_id]).">$w[c_name]</a> [$w[c_years]] $w[c_country]</td>";
    echo "<td><a href=ptracks.php?u_id=$us[u_id]&t_id=$w[t_id]>";
    if ($w[correct] == 0) echo "<font color=brown>";
    echo "$w[t_name] $w[t_len]</td>";
    //echo "<td>".gmdate('H:i:s', $w[c_len])."</td>";
    //echo "<td>";
    //if (round($w[r1])>0) echo round($w[r1])."</td>";
    echo "<td><center>";
    if ($w[correct] == 0) echo "<b><font color=brown>";
    echo round(100*$w[correct], 1)."%";
    echo "<td><center>";
    if ($w[cnt]>0) echo "$w[cnt]</td>";
    echo "<td><center>";
    if ($w[wrong2]>0) echo round(100*$w[wrong2], 1)."%";
    echo "<td><center>";
    if ($w[sec]>0) echo gmdate('H:i:s', round($w[sec]))."</td>";
    echo "<td><center>";
    if ($w[acent]!=0) echo round($w[acent], 1);
    echo "<td><center>";
    if ($w[cent]!=0) echo round($w[cent], 1);
    echo "</tr>";
  }
  echo "</table>";
  echo "<br>Only tracks, asked more than once and answered at least one time wrong are shown.";
  
  // SELECT u_name,cc_qlog.u_level,count(*) as cnt,avg(l_r1) as r1,avg(l_ok) FROM `cc_qlog` LEFT JOIN cc_users USING (u_id) WHERE c_id=192 GROUP BY u_id,cc_qlog.u_level HAVING cnt>3 ORDER BY r1 desc 
  stop_time();
?>