<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  secure_variable("cab");
  secure_variable("u_id");
  secure_variable("level");
  secure_variable("f_time");
  secure_variable("a_count");

  if (!isset($cab)) $cab = "";
  if (!isset($u_id)) $u_id = -1;
  
  show_user_logs($u_id, $cab, $level, $f_time, $a_count);
  stop_time();
?>