<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  
  sleep(2);
  echo "Hello world!";
?>