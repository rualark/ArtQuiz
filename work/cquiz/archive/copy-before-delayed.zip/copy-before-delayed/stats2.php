<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";

  start_time();
  secure_variable("su_id");
  
  if ($u_id==0) $u_id = $us[u_id];
  
  $q5 = "SELECT COUNT(*) as cnt FROM cc_ctracks";
  $r5 = mysql_query($q5);
  echo mysql_error();
  $w = mysql_fetch_assoc($r5);
  $q5 = "SELECT COUNT(DISTINCT t_id) as cnt FROM cc_qlog WHERE u_id='$u_id'";
  $r5 = mysql_query($q5);
  echo mysql_error();
  $w2 = mysql_fetch_assoc($r5);
  $q5 = "SELECT COUNT(*) as cnt FROM cc_qblocks";
  $r5 = mysql_query($q5);
  echo mysql_error();
  $w3 = mysql_fetch_assoc($r5);
  $q5 = "SELECT COUNT(DISTINCT (t_id*1000+b_id)) as cnt FROM cc_qlog WHERE u_id='$u_id'";
  $r5 = mysql_query($q5);
  echo mysql_error();
  $w4 = mysql_fetch_assoc($r5);
  
  $r = mysql_query("SELECT * FROM cc_users 
    WHERE cc_users.u_id='$u_id'");
  echo mysql_error();
  $ua = mysql_fetch_array($r);
  
  echo "$ua[u_name] has heared <b>".round($w4[cnt]/$w3[cnt]*100, 0)."%</b> of $w3[cnt] blocks and ";
  echo " <b>".round($w2[cnt]/$w[cnt]*100, 0)."%</b> of $w[cnt] tracks. ";
  stop_time();
?>