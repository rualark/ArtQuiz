<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  secure_variable("u_id");

  load_comps();
  
  $order = "anum desc";
  if (isset($sort)) $order = $sort;
  $cond = "";
  if (isset($u_id)) {
    if ($u_id == 0) $u_id = $us[u_id];
    $r = mysql_query("SELECT * FROM cc_users WHERE u_id='$u_id'");
    echo mysql_error();
    $ua = mysql_fetch_array($r);
    $cond = "AND cc_ur.u_id = $u_id";
    echo "<b>Islands for user $ua[u_name]:</b><br>";
  }
  $q = "SELECT *, hex(cc_ur.r_cab) as cab,
    count(cc_ur.u_id) as unum,
    sum(cc_ur.r_total) as anum
    FROM cc_ur
    WHERE cc_ur.r_level=$level_cust AND cc_ur.r_cab != x'' $cond
    GROUP BY cc_ur.r_cab
    ORDER BY $order
    LIMIT $isles_max_count";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);

  echo "<center>";
  echo "<table border=1>";
  echo "<tr>";
  echo "<th width=550>Islands of composers</th>";
  echo "<th>King</th>";
  echo "<th title='Rating of the king on this island'>King R</th>";
  echo "<th title='Your rating on the island'>My R</th>";
  echo "<th title='Average rating on the island'>AVG R</th>";
  echo "<th title='Number of composers on the island'>CN</th>";
  echo "<th title='Total number of answers on the island'>ANS</th>";
  echo "<th title='Number of users on the island'>UN</th>";
  echo "</tr>";
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_array($r);
    // Load king
    $q3 = "SELECT * FROM cc_isles 
      LEFT JOIN cc_users ON (cc_users.u_id = cc_isles.u_id)
      LEFT JOIN cc_ur ON (cc_isles.u_id = cc_ur.u_id AND cc_isles.i_cab = cc_ur.r_cab)
      WHERE cc_isles.i_cab = x'$w[cab]'
    ";
    //echo $q3;
    $r3 = mysql_query($q3);
    echo mysql_error();
    $n3 = mysql_numrows($r3);
    $w3 = mysql_fetch_assoc($r3);
    $ca = unpack_ca($w[cab]);
    load_isle($ca, $isles_max_comps);
    echo "<tr>";
    echo "<td>";
    echo " <a href=prefs.php?ilevel=$level_cust&cab=$w[cab]><img valign=center border=0 title='Click to move to this island' src=images/play.gif></a> ";
    echo "<a href=rating.php?level=$level_cust&cab=$w[cab]>";
    $same=1;
    for ($x=0; $x<strlen($w[cab]); $x++) {
      if ($w[cab][$x] != $us[cab][$x]) {
        $same = 0;
        break;
      }
    }
    if ($same == 1) echo "<font color=green>";
    echo "$isle_cst";
    echo "</td>";
    echo "<td>";
    echo "<a href=stats.php?su_id=$w3[u_id]>";
    if ($w3[u_id] == $us[u_id]) echo "<font color=green>";
    echo "$w3[u_name]";
    if ($w3[u_name] == "") echo "<center>-";
    else show_crown($w3[r_total]);
    echo "</td>";
    echo "<td><center>";
    if ($w3[r1_max]>0) echo "$w3[r1_max]";
    if ($w3[u_name] == "") echo "-";
    echo "</td>";
    // Load my rating
    $q2 = "SELECT * FROM cc_ur WHERE u_id=$us[u_id] AND r_cab=x'$w[cab]'";
    $r2 = mysql_query($q2);
    echo mysql_error();
    $n2 = mysql_numrows($r2);
    $w2 = mysql_fetch_assoc($r2);
    $font = "";
    if (($w2[r_r1] >= $w3[r1_avg]) || ($w3[u_id] == $us[u_id])) $font .= "<b>";
    if ($w3[u_id] == $us[u_id]) $font .= "<font color=green>";
    if ($w2[r_total] == 0) {
      $st = "-";
      $title = "You have not played on this island yet.";
    } elseif ($w2[r_total] > $rating_min_isle) {
      $st = "$w2[r_r1]";
      $title = "";
    } else {
      $st = "...";
      $title = "Less than $rating_min_isle questions answered ($w2[r_total]). Your rating is $w2[r_r1].";
    }
    echo "<td title='$title'>$font<center>$st";
    //if ($w[u_id] == $us[u_id]) echo "- \" -";
    echo "</td>";
    echo "<td><center>$w3[r1_avg]";
    echo "</td>";
    echo "<td><center>$isle_cnum";
    echo "</td>";
    echo "<td><center>$w[anum]";
    echo "</td>";
    echo "<td><center>$w[unum]";
    echo "</td>";
    echo "</tr>";
  }
  echo "</table></center>";
  //echo "<br>Please pay attention, that I will hide users with less than 30 answers from rating table soon.";
  echo "<br>Table includes only top $isles_max_count islands. You island is highlited in green.<br>";
  show_legend();
  stop_time();
?>