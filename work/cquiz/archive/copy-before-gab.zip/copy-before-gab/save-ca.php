<?
  include "qlib.php";
  include "auth.php";

  header('Content-type: application/force-download');
  error_reporting(0);
  //error_reporting(E_ALL);
  
  echo "$us[u_ca]";
?>