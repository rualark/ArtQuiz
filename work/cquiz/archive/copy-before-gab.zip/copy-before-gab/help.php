<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  start_time();
  show_help();
  stop_time();
?>