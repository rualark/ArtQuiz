<?
  function make_color($r, $g=-1, $b=-1)
  {
    if (is_array($r) && sizeof($r) == 3)
        list($r, $g, $b) = $r;

    $r = intval($r); $g = intval($g);
    $b = intval($b);

    $r = dechex($r<0?0:($r>255?255:$r));
    $g = dechex($g<0?0:($g>255?255:$g));
    $b = dechex($b<0?0:($b>255?255:$b));

    $color = (strlen($r) < 2?'0':'').$r;
    $color .= (strlen($g) < 2?'0':'').$g;
    $color .= (strlen($b) < 2?'0':'').$b;
    return '#'.$color;
  }

  function secure_variable($st) {
    GLOBAL ${$st};
    if (isset($_GET[$st])) ${$st} = mysql_real_escape_string($_GET[$st]);
  }

  function secure_variable_post($st) {
    GLOBAL ${$st};
    if (isset($_POST[$st])) ${$st} = mysql_real_escape_string($_POST[$st]);
  }

  function rnd($x1, $x2) {
    return ($x2-$x1)*(mt_rand()/mt_getrandmax())+$x1;
  }
  
  function write_log($path, $st) {
    $fh = fopen($path, "a");
    fputs($fh, $st."\n");
    fclose($fh);
  }

  function meta_conv($meta) {
    return str_replace("?", "", mb_convert_encoding(mb_convert_encoding($meta, "CP1252", "UTF-8"), "UTF-8", "CP1251"));
  }
  
  function make_country_color($st) {
    GLOBAL $countrycolor;
    $color = "black";
    if ($countrycolor == 0) return $color;
    if (strpos($st, "ITA") !== FALSE) $color="red";
    if (strpos($st, "FRA") !== FALSE) $color="blue";
    if (strpos($st, "FLM") !== FALSE) $color="blue";
    if (strpos($st, "ENG") !== FALSE) $color="green";
    if (strpos($st, "BRI") !== FALSE) $color="green";
    if (strpos($st, "IRL") !== FALSE) $color="green";
    if (strpos($st, "DNK") !== FALSE) $color="darkbrown";
    if (strpos($st, "DEU") !== FALSE) $color="brown";
    if (strpos($st, "AUT") !== FALSE) $color="brown";
    if (strpos($st, "ESP") !== FALSE) $color="orange";
    if (strpos($st, "EST") !== FALSE) $color="yellow";
    if (strpos($st, "HUN") !== FALSE) $color="yellow";
    if (strpos($st, "CHE") !== FALSE) $color="yellow";
    if (strpos($st, "CZE") !== FALSE) $color="yellow";
    if (strpos($st, "POL") !== FALSE) $color="yellow";
    if (strpos($st, "BOH") !== FALSE) $color="yellow";
    if (strpos($st, "ARM") !== FALSE) $color="yellow";
    if (strpos($st, "FIN") !== FALSE) $color="lightblue";
    if (strpos($st, "NOR") !== FALSE) $color="lightblue";
    if (strpos($st, "ARG") !== FALSE) $color="lightgreen";
    if (strpos($st, "BRA") !== FALSE) $color="lightgreen";
    if (strpos($st, "RUS") !== FALSE) $color="pink";
    return $color;
  }

  function make_country_bgcolor($st) {
    GLOBAL $countrycolor;
    $color = "white";
    if ($countrycolor == 0) return $color;
    if (strpos($st, "EST") !== FALSE) $color="#333333";
    if (strpos($st, "HUN") !== FALSE) $color="#333333";
    if (strpos($st, "CHE") !== FALSE) $color="#333333";
    if (strpos($st, "CZE") !== FALSE) $color="#333333";
    if (strpos($st, "POL") !== FALSE) $color="#333333";
    if (strpos($st, "BOH") !== FALSE) $color="#333333";
    if (strpos($st, "ARM") !== FALSE) $color="#333333";
    if (strpos($st, "FIN") !== FALSE) $color="#333333";
    if (strpos($st, "NOR") !== FALSE) $color="#333333";
    if (strpos($st, "ARG") !== FALSE) $color="#333333";
    if (strpos($st, "BRA") !== FALSE) $color="#333333";
    if (strpos($st, "RUS") !== FALSE) $color="#333333";
    return $color;
  }
?>