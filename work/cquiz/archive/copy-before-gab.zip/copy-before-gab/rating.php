<?
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";

  start_time();
  
  secure_variable("level");
  secure_variable("sort");
  secure_variable("c_id");
  secure_variable("cab");

  if (!isset($level)) $level = $us[u_level];
  $rating_min = $rating_min_total;
  if ($level == $level_cust) $rating_min = $rating_min_isle;
  echo "<center><form action=rating.php method=get>";
  echo "Difficulty: ";
  //echo "<select name=level onChange='this.form.submit();'>";
  for ($i=1; $i<$level_cust; $i++) {
    if ($i == $level) echo "<b><font style='BACKGROUND-COLOR: yellow'>";
    else echo "<a href=rating.php?level=$i>";
    if ($i == $us[u_level]) echo " <font color=brown>";
    echo "".$level_name[$i]."</b></font></font></a> | ";
  }
  if (($level == $level_cust) && ($cab == "")) {
    echo "<br>Please select difficulty to view ratings.";
    exit;
  }
  echo "Composer: ";
  $cond = "";
  if ($cab != "") $cond .= " AND cc_qlog.u_cab = x'$cab' ";
  $q = "SELECT *,
    count(*) as cnt, 
    avg(l_ok) as cor,
    sum(IF(cc_qlog.u_id-$us[u_id], 0, 1)*l_ok)/sum(IF(cc_qlog.u_id-$us[u_id], 0, 1)) as cor2
    FROM cc_qlog
    LEFT JOIN cc_composers USING (c_id)
    WHERE cc_qlog.u_level=$level $cond
    GROUP BY cc_qlog.c_id
    ORDER BY cnt DESC
    LIMIT 1000
    ";
  //echo $q;
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  echo "<input type=hidden name=level value=$level>";
  echo "<input type=hidden name=cab value=$cab>";
  echo "<select name=c_id onChange='this.form.submit();'>";
  echo "<option value=0>*** All composers</option>";
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    //print_r($w);
    echo "<option value=$w[c_id]";
    if ($c_id == $w[c_id]) echo " selected";
    echo ">$w[c_name] ($w[cnt] - ".round($w[cor2]*100, 1)."% - ".round($w[cor]*100, 1)."%)</option>";
  }
  echo "</select>";
  echo "</form>";
  if ($cab != "") {
    load_isle($cab);
    create_isle_cst(unpack_ca($cab));
    echo "<b>Island</b>: $isle_cst3 <a href=prefs.php?ilevel=$level_cust&cab=$cab> <img valign=center border=0 title='Click to move to this island' src=images/play.gif></a>";
    echo " <a href=logs.php?cab=$cab>Logs</a> <a href=klogs.php?cab=$cab>News</a>";
    echo "<br>";
    $isle_cond = "AND cc_ur.r_cab = x'$cab'";
    $isle_cond2 = "AND cc_qlog.u_cab = x'$cab'";
    $isle_group2 = ", cc_qlog.u_cab";
  } else {
  }
  echo "<table border=1>";
  echo "<tr>";
  echo "<th>User</th>";
  if ($level ==$level_cust && $cab == "") echo "<th>Isle</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=r_r1 desc'>Rating</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=r_total desc'>Answers</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=rght desc'>Correct</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=rghtp desc'>Period</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=cc_ur.r_avsec'>ATT, sec</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=r_avcent2'>AAYE</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=r_oneblock desc'>1M</th>";
  if ($level != $level_cust) echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=r_allcomp desc'>AC</th>";
  echo "<th><a href='rating.php?cab=$cab&c_id=$c_id&level=$level&sort=u_last desc'>Last online</th>";
  //echo "<th><a href='rating.php?sort=cent desc'>Years error</th>";
  echo "</tr>";

  // Load isle
  if ($level == $level_cust && $cab != "") {
    $q = "SELECT *,cc_isles.u_id as u_id FROM cc_isles LEFT JOIN cc_users ON (cc_isles.nu_id=cc_users.u_id) WHERE i_cab = x'$cab'";
    $r = mysql_query($q);
    echo mysql_error();
    $n = mysql_numrows($r);
    $wi = mysql_fetch_array($r);
  }

  $order = "r_r1 desc";
  if (isset($sort)) $order = $sort;
  $cond = "";
  $q = "SELECT *,
    hex(cc_ur.r_cab) as cab,
    (r_right/cc_ur.r_total) as rght,
    (r_oneblock/cc_ur.r_total) as ob,
    (r_allcomp/cc_ur.r_total) as ac,
    (r_rightp/cc_ur.r_total) as rghtp,
    UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(u_last) as u_passed
    FROM cc_users
    LEFT JOIN cc_ur ON (cc_ur.u_id=cc_users.u_id AND cc_ur.r_level=$level $isle_cond)
    WHERE cc_ur.r_total>=$rating_min
    ORDER BY $order
    LIMIT $rating_max_count";
  if ($c_id>0) {
    $q = "SELECT *,
      hex(cc_qlog.u_cab) as cab,
      avg(l_ok) as rght,
      avg(1-l_wrong2) as rghtp,
      avg(l_r1) as r_r1,
      avg(l_sec) as r_avsec,
      avg(cc_qlog.u_allcomp) as ac,
      avg(cc_qlog.u_oneblock) as ob,
      sum(abs(l_cent))/sum(l_ok) as r_avcent2,
      count(*) as r_total,
      UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(u_last) as u_passed
      FROM cc_qlog
      LEFT JOIN cc_users USING (u_id)
      WHERE cc_qlog.u_level=$level AND c_id=$c_id AND u_name != '' $isle_cond2
      GROUP BY u_id , cc_qlog.u_cab
      HAVING r_total>=$rating_min_total2
      ORDER BY $order
      LIMIT $rating_max_count";
  }
  //echo $q;
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_array($r);
    echo "<tr>";
    echo "<td><a href=stats.php?su_id=$w[u_id]>";
    //if ($w[t_id]>0) echo "<font color=brown>";
    echo "$w[u_name]</a> ";
    if ($level == $level_cust && $cab != "") {
      if ($wi[u_id] == $w[u_id]) echo show_crown($wi[r_total], $wi[u_id2], $wi[i_unum]);
      if ($w[r_total] <= $isle_king_min[0]) 
        echo "<img height=15 title='Player has to answer more than $isle_king_min[0] questions to be able to become king (currently $w[r_total])' src=images/dummy.png>";
    }
    echo "</td>";
    if ($level == $level_cust && $cab == "") {
      echo "<td>";
      if ($w[cab] != "") {
        load_isle($w[cab]);
        echo "<a title='$is[i_cst2]' href=rating.php?level=$level_cust&cab=$w[cab]>Isle";
      }
      echo "</td>";
    }
    echo "<td><center><a href=graph.php?u_id=$w[u_id]&level=$level";
    if ($level == $level_cust) echo "&cab=$w[cab]";
    echo ">".round($w[r_r1])."</td>";
    echo "<td><center>$w[r_total]</td>";
    echo "<td title='".round($w[rght]*$w[r_total])."'><center>".round($w[rght]*100, 1)."%</td>";
    echo "<td><center>".round($w[rghtp]*100, 1)."%</td>";
    echo "<td title='Spent ".gmdate("H:i:s", round($w[r_avsec]*$w[r_total]))." here'><center>".round($w[r_avsec], 2)."</td>";
    echo "<td><center>".round($w[r_avcent2], 1)."</td>";
    echo "<td><center>".round($w[ob]*100, 1)."%</td>";
    if ($level != $level_cust) echo "<td><center>".round($w[ac]*100, 1)."%</td>";
    echo "<td><center>";
    if ($w[u_passed] < 60*60) echo "<b>";
    echo "$w[u_last]</td>";
    echo "</tr>";
  }
  echo "</table></center>";
  if ($cab != "") {
    echo "<p align=center>Island was created by $wi[u_name] on $wi[i_since]<br>";
    echo "<a href=isles.php?cab=$cab>Find similar islands</a><p>";
  }
  //echo "<br>Please pay attention, that I will hide users with less than 30 answers from rating table soon.";
  if ($c_id>0) echo "<br>Table includes only top $rating_max_count users with at least $rating_min_total2 answers.<br>";
  else echo "<br>Table includes only top $rating_max_count users with at least $rating_min answers.<br>";
  echo "Users currently answering a question are marked red. Active time less than an hour ago is bold.<br>";
  echo "In composers drop-down list you can see (Total number of answers - Your correctness - Average correctness) for each composer.";
  show_legend();
  stop_time();
/*
  Adding custom isles
  - Change rating calculation for Custom to make it more comparable between isles
  + Total rating: easy (if more than 60) + normal (if more than 60) + hard (if more than 60) + insane (if more than 60) + 
    Crown (0.5 - 1) * Sqrt(ANUM*UNUM)
  + Isle log: new, clears, king change, spammer change, crown change
    l_id, u_id, u_id2, ou_id, ou_id2, r_total, i_crown, cu_id, nu_id
  + Convert isle_crown_min to array isle_king_min
  - After answer show only stats for current level or island
*/
?>