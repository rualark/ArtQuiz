<?
  include "mysql.php";
  include "qlib.php";
  include "auth.php";
  include "style.php";
  include "menu.php";
  
  secure_variable("u_id");
  secure_variable("level");

  start_time();
  
  if (isset($u_id)) load_user($u_id);
  $u_id = $us[u_id];
  if (!isset($level)) $level = $us[u_level];
  
  echo "<script type=text/javascript src=https://www.google.com/jsapi></script>";
  echo "<script type=text/javascript>";
  echo "google.load('visualization', '1', {packages:['corechart']});";
  echo "google.setOnLoadCallback(drawChart);";
  echo "function drawChart() {";
  echo "var data1 = google.visualization.arrayToDataTable([";
  echo "['Date', 'Correct period (%)', 'Correct (%)', 'Rating'],";
  
  $cond = "";
  $title = "level ".$level_name[$level];
  if (isset($cab)) {
    load_isle($cab);
    $title = "island $is[i_cst2]";
    $cond .= "AND u_cab = x'$cab'";
  }
  $q = "
    SELECT * FROM cc_qlog
    WHERE u_id=$u_id AND u_level=$level $cond
    ORDER BY l_time,l_id
  ";
  $r = mysql_query($q);
  $n = mysql_numrows($r);
  if ($n<5) die ("]);}</script>Not enough answers to build graph. Please answer more questions.");
  $r1 = 0;
  $cor = 0;
  $corp = 0;
  $sec = 0;
  $avcent = 0;
  $data2 = "";
  $wrong_n = 0;
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $r1 = ($r1*$i + $w[l_r1])/($i+1);
    $cor = ($cor*$i + $w[l_ok]*100)/($i+1);
    if ($w[l_ok] == 0) {
      $avcent = ($avcent*$wrong_n + abs($w[l_cent]))/($wrong_n+1);
      $wrong_n ++;
    }
    $corp = ($corp*$i + (1-$w[l_wrong2])*100)/($i+1);
    if ($w[l_sec]<3600) $sec = ($sec*$i + $w[l_sec])/($i+1);
    $catt[$w[c_id]] += $w[l_sec];
    $cnum[$w[c_id]] ++;
    $date = substr($w[l_time], strpos($w[l_time], "-")+1, 100);
    $date = substr($date, 0, strpos($date, " "));
    $date = $w[l_time];
    if ($w[l_sec] < 300) $sec2 = $w[l_sec];;
    if ($i > 0) {
      echo "['$date', $corp, $cor, $r1]\n";
      $data2 .= "['$date', $sec2, $avcent]\n";
      if ($i < $n-1) {
        echo ",";
        $data2 .= ",";
      }
    }
  }
  echo "]);";

  echo "var data2 = google.visualization.arrayToDataTable([";
  echo "['Date', 'Think time (sec)', 'Absolute years mistake'],";
  echo $data2;
  echo "]);";
  
  // Count id2
  $q = "SELECT c_id2, count(*) as cnt, avg(l_ok)*100 as aok 
    FROM cc_qlog WHERE u_id=$u_id AND u_level=$level $cond
    GROUP BY c_id2";
  $r = mysql_query($q);
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $cok2[$w[c_id2]] = $w[aok];
    // How many times user selected c_id2 wrong
    $wcnt2[$w[c_id2]] = round($w[cnt]*(1-$w[aok]/100));
  }

  $q = "SELECT *, count(*) as cnt, avg(l_ok)*100 as aok 
    FROM cc_qlog 
    LEFT JOIN cc_composers USING (c_id)
    WHERE u_id=$u_id AND u_level=$level $cond
    GROUP BY c_id";
  $r = mysql_query($q);
  $n = mysql_numrows($r);
  $first = 1;
  $n2 = $n;
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $cok[$w[c_id]] += $w[aok];
    // How many times c_id was playing and user selected not c_id
    $wcnt[$w[c_id]] = round($w[cnt]*(1-$w[aok]/100));
    $wa[$i] = $w;
  }

  // Count most wrong
  $q = "SELECT c_name4, cc_qlog.c_id, c_id2, count(c_id2) as cnt 
    FROM cc_qlog 
    LEFT JOIN cc_composers ON (cc_composers.c_id = cc_qlog.c_id2)
    WHERE cc_qlog.c_id != c_id2 AND u_id=$u_id AND u_level=$level $cond
    GROUP BY cc_qlog.c_id, c_id2
    ORDER BY cnt DESC";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    // Count how many times user selected c_id2 when it was c_id really out of times when c_id was playing and user was wrong
    // Put it into array, where c_id is key
    $cnc[$w[c_id]] += 1;
    if ($cnc[$w[c_id]] < 3) {
      if ($cname[$w[c_id]] != "") $cname[$w[c_id]] .= ", ";
      $cname[$w[c_id]] .= "$w[c_name4] (".round($w[cnt]/$wcnt[$w[c_id]]*100)."% - $w[cnt] of ".$wcnt[$w[c_id]].")";
    }
  }

  // Count most wrong2
  $q = "SELECT c_name4, cc_qlog.c_id, c_id2, count(cc_qlog.c_id) as cnt 
    FROM cc_qlog 
    LEFT JOIN cc_composers ON (cc_composers.c_id = cc_qlog.c_id)
    WHERE cc_qlog.c_id != c_id2 AND u_id=$u_id AND u_level=$level $cond
    GROUP BY c_id2, cc_qlog.c_id
    ORDER BY cnt DESC";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    // Count how many times it was c_id when user selected c_id2 out of times when user selected c_id2 wrong
    // Put it into array, where c_id2 is key
    $cnc2[$w[c_id2]] += 1;
    if ($cnc2[$w[c_id2]] < 4) {
      if ($cname2[$w[c_id2]] != "") $cname2[$w[c_id2]] .= ", ";
      $cname2[$w[c_id2]] .= "$w[c_name4] (".round($w[cnt]/$wcnt2[$w[c_id2]]*100)."% - $w[cnt] of ".$wcnt2[$w[c_id2]].")";
    }
  }

  // Count id
  $q = "SELECT *, count(*) as cnt, avg(l_ok)*100 as aok 
    FROM cc_qlog 
    LEFT JOIN cc_composers USING (c_id)
    WHERE u_id=$u_id AND u_level=$level $cond
    GROUP BY c_id";
  $r = mysql_query($q);
  $n = mysql_numrows($r);
  $first = 1;
  echo "var data3 = new google.visualization.DataTable();\n";
  echo "data3.addColumn('string', 'Composer');\n";
  echo "data3.addColumn('number', 'Correct');\n";
  echo "data3.addColumn('number', 'Correct guess');\n";
  echo "data3.addColumn('string', 'Period');\n";
  echo "data3.addColumn('number', 'Questions');\n";
  echo "data3.addColumn({type: 'string', role: 'tooltip'});\n";
  //echo "var data3 = google.visualization.arrayToDataTable([\n";
  //echo "['Composer', 'Correct', 'Correct guess', 'Period', 'Questions', 'Tip'],";
  echo "data3.addRows([";
  for ($i=0; $i<$n2; $i++) {
    $w = $wa[$i];
    $cid = $w[c_id];
    if ($first == 0) echo ", ";
    $first = 0;
    echo "['$w[c_name4]', $cok[$cid], $cok2[$cid], '$w[p_name]', ".
      " $w[cnt], '<b>Selected wrong</b>: $cname[$cid]<br><b>Selected when</b>: $cname2[$cid]<br><br>ATT: ".round($catt[$cid]/($cnum[$cid]+0.0000001))." sec']\n";
  }
  echo "]);";
  echo "var options1 = {
    vAxes: {0: {format: '#'}, 1: {format: '#\\'%\\''}}, 
    series: {
      0:{ type: 'line', targetAxisIndex: 1 },
      1: { type: 'line', targetAxisIndex: 1},
      2: { type: 'line', targetAxisIndex: 0}
    },
    chartArea: {left: 70, top: 60, width: 770, height: 380},
    title: '$us[u_name] graphs for $title'};";
  echo "var options2 = {
    vAxes: {0: {format: '#'}, 1: {format: '#'}}, 
    series: {
      0:{ type: 'line', targetAxisIndex: 0 },
      1: { type: 'line', targetAxisIndex: 1},
    },
    chartArea: {left: 70, top: 30, width: 770, height: 410},
    title: ''};";
  $min_ok = min($cok);
  $max_ok = max($cok);
  $min_ok2 = min($cok2);
  $max_ok2 = max($cok2);
  $frame = 0.01;
  $hmax = $max_ok + ($max_ok-$min_ok)*$frame;
  $hmin = $min_ok - ($max_ok-$min_ok)*$frame;
  $vmax = $max_ok2 + ($max_ok2-$min_ok2)*$frame;
  $vmin = $min_ok2 - ($max_ok2-$min_ok2)*$frame;
  echo "var options3 = {\n";
  echo "title: '$us[u_name] correct correlation for $title',\n";
  echo "hAxis: {title: 'Correct', maxValue: $hmax, minValue: $hmin, format: '#\\'%\\''},\n";
  echo "vAxis: {title: 'Correct guess', maxValue: $vmax, minValue: $vmin, format: '#\\'%\\''},\n";
  echo "bubble: {textStyle: {fontSize: 11}},\n";
  echo "sizeAxis: {minSize: 10, maxSize: 50},\n";
  echo "chartArea: {left: 70, top: 30, width: 690, height: 500},\n";
  echo "};\n";

?>
var formatter = new google.visualization.NumberFormat({
    fractionDigits: 1,
    suffix: '%'
});
var formatter2 = new google.visualization.NumberFormat({
    fractionDigits: 1,
});
formatter.format(data3, 1);
formatter.format(data3, 2);
formatter.format(data1, 1);
formatter.format(data1, 2);
formatter2.format(data1, 3);
formatter2.format(data2, 2);

<?
  echo "function c3selectHandler() {\n";
  echo "var selectedItem = chart3.getSelection()[0];\n";
  echo "if (selectedItem) {\n";
  echo "var comp = data3.getValue(selectedItem.row, 0);\n";
  echo "var topping = data3.getValue(selectedItem.row, 5);\n";
  echo  "overlib(topping, CAPTION,'<b>Statistics of wrong answers for ' + comp,CGCOLOR,'#ffffee',FGCOLOR,'#eeeeff',
    TEXTPADDING,8,CAPTIONPADDING,4,TEXTFONTCLASS,'oltxt',CAPTIONFONTCLASS,'olcap',WRAP,BASE,2,HAUTO);";
  echo "}\n";
  echo "}\n";
  echo "var chart1 = new google.visualization.LineChart(document.getElementById('chart_div1'));";
  echo "chart1.draw(data1, options1); ";
  echo "var chart2 = new google.visualization.LineChart(document.getElementById('chart_div2'));";
  echo "chart2.draw(data2, options2); ";
  echo "var chart3 = new google.visualization.BubbleChart(document.getElementById('chart_div3'));";
  echo "google.visualization.events.addListener(chart3, 'select', c3selectHandler);\n";
  echo "chart3.draw(data3, options3); }";
  echo "</script>";
  echo "<div id=chart_div1 style='width: 900px; height: 450px;'></div>";
  echo "<br>";
  echo "<div id=chart_div2 style='width: 900px; height: 450px;'></div>";
  echo "<br>";
  echo "<div id=chart_div3 style='width: 900px; height: 600px;'></div>";
  echo "<a href='javascript:void(0);' onclick=\"overlib('', TIMEOUT, 1); return false;\">Close popup</a><br>";
  echo "Size of the bubble shows number of questions asked<br>";
  stop_time();
?>