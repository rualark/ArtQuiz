<?
  echo microtime(TRUE);
?>