<?
  include "qlib.php";
  include "style.php";
  include "analytics.php";
  $page_width="100%";
  include "ca-menu.php";
  
  $max_painters = 30;
  $col_num = 1;
  $img_width = 600;

  start_time();
  secure_variable("c_id");
  secure_variable("t_id");
  secure_variable("b_id");
  secure_variable("a_id");
  secure_variable("p_id");

  if (isset($a_id)) {
    // Check duplicate
    $q = "SELECT * FROM ca_log WHERE a_id='$a_id' AND p_id='$p_id' AND t_id='$t_id' AND UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(l_time) < 30*60";
    $r = mysql_query($q);
    echo mysql_error();
    $n = mysql_numrows($r);
    if ($n == 0) {
      // Insert
      mysql_query("INSERT INTO ca_log VALUES('', '$c_id', '$t_id', '$b_id', '$a_id', '$p_id', NOW(), '".get_ip()."', '', '$_SERVER[HTTP_USER_AGENT]', '', '')");
      echo mysql_error();
    } else echo 'Duplicate';
    die ("<script language=\"javascript\">location.replace(\"ca-input.php\");</script>"); 
  }
  
  start_time();
  
  $us[u_id] = 0;
  $us[u_oneblock] = 1;
  $us[u_level] = 2;
  
  if (!isset($t_id)) {
    $b_id = choose_block_new();
  }
  load_track($t_id);
  
  echo "<table>";
  echo "<tr><td bgcolor=lightgray><b><center>Associate this music with artist who was born before $ts[c_name4]:";
  echo "<td rowspan=2 bgcolor=black>";
  echo "<td bgcolor=lightgray><b><center>Or artist who was born after $ts[c_name4]:";
  echo "<tr><td valign=top><table>";
  echo "<tr><td width=$img_width bgcolor=#eeeeff valign=top>";
  //echo "<a href=ca.php>MENU</a><br><br>";

  echo "<table><tr><td valign=top>";
  show_player($t_id, $b_id, $us[u_oneblock], $play_symlinks, 1, $b_id);
  echo "<td valign=top>";
  echo "<br><a href=am.php?c_id=$ts[c_id]>$ts[c_name4]</a> $ts[c_country] $ts[p_name] ($ts[c_years])<br><a href=ptracks.php?t_id=$ts[t_id]>$ts[t_name]</a> ";
  echo meta_conv($ts[t_meta2]);
  echo "<p><table><tr><td>";
  echo "<form action=ca-input.php>";
  echo "<input type=hidden name=t_id value='$t_id'>";
  echo "<input type=hidden name=b_id value='$b_id'>";
  echo "<input type=submit value='Change paintings'></form>";
  echo "<td>";
  echo "<form action=ca-input.php>";
  echo "<input type=submit value='Change music & paintings'></form>";
  echo "</table>";
  echo "</table>";
  
  // Find years frame
  $q = "SELECT ABS(a_start-'$ts[c_start]') as dist FROM {$adb}artists ORDER BY dist LIMIT $max_painters";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $years_frame = $w[dist];
  }
  //echo "Years frame: $years_frame<br>";

  echo "<tr>";
  // Show old composers
  $q = "SELECT *, (a_start-'$ts[c_start]') as dy FROM {$adb}artists HAVING dy<=0 ORDER BY dy DESC LIMIT ".($max_painters-1);
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $p_id = mt_rand(1, $w[p_num]);
    echo "<td valign=top><center>";
    //echo "<div style='width: {$img_width}px; height: {$img_width}px; vertical-align: middle; display: table-cell'>";
    echo "<a href=# onclick='location.replace(\"ca-input.php\" + \"?c_id=$ts[c_id]&t_id=$ts[t_id]&b_id=$b_id&a_id=$w[a_id]&p_id=$p_id\")'>";
    // style='margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%;'
    $img_url = show_painting($w[a_id], $p_id, $img_width, $img_width);
    echo "</a><br><a target=_blank href=artist.php?a_id=$w[a_id]>$w[a_name2]</a> ".strtoupper(substr($w[a_nation], 0, 3))."-".(substr($w[a_years], 0, 4))." ".$w[a_genre];
    echo " <a target=_blank href=$img_url><img height=14 src=i/zoom_in.png></a> ";
    echo " <a target=_blank href='http://images.google.com/searchbyimage?image_url=$img_url'><img height=16 src=images/help.png></a> ";
    //echo "</div>";
    if (($i+2) % ($col_num) == 0) echo "<tr>";
  }
  echo "</table>";

  // Show new composers
  //echo "<td bgcolor=black>";
  echo "<td valign=top><table>";
  $q = "SELECT *, (a_start-'$ts[c_start]') as dy FROM {$adb}artists HAVING dy>0 ORDER BY dy LIMIT $max_painters";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $p_id = mt_rand(1, $w[p_num]);
    echo "<td valign=top><center>";
    //echo "<div style='width: {$img_width}px; height: {$img_width}px; vertical-align: middle; display: table-cell'>";
    echo "<a href=# onclick='location.replace(\"ca-input.php\" + \"?c_id=$ts[c_id]&t_id=$ts[t_id]&b_id=$b_id&a_id=$w[a_id]&p_id=$p_id\")'>";
    // style='margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%;' 
    $img_url = show_painting($w[a_id], $p_id, $img_width, $img_width);
    echo "</a><br><a target=_blank href=artist.php?a_id=$w[a_id]>$w[a_name2]</a> ".strtoupper(substr($w[a_nation], 0, 3))."-".(substr($w[a_years], 0, 4))." ".$w[a_genre];
    echo " <a target=_blank href=$img_url><img height=14 src=i/zoom_in.png></a> ";
    echo " <a target=_blank href='http://images.google.com/searchbyimage?image_url=$img_url'><img height=16 src=images/help.png></a> ";
    //echo "</div>";
    if (($i+1) % ($col_num) == 0) echo "<tr>";
  }
  echo "</table>";
  echo "</table>";
  echo "<p>Please select painting, which best represents music that is playing. Please be careful at making your decisions, because it will influence overall statistics.";
  echo "<p>Please refresh page if you cannot find appropriate association.";
  
  stop_time();
?>
<script>window.scroll(0, 100);</script>