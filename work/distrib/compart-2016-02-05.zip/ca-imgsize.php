<?
  include "qlib.php";
  
  start_time();
  $q = "SELECT p_num, a_id FROM {$adb}artists";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    for ($p=1; $p<$w[p_num]; $p++) {
      $p_name = str_pad($p, 4, '0', STR_PAD_LEFT);
      $img_url = "../aquiz/paintings/$w[a_id]/$p_name.jpg";
      $ii = getimagesize($img_url);
      echo "$p $ii[0] $ii[1]<br>";
      mysql_query("INSERT INTO {$adb}paintings VALUES('$w[a_id]', '$p', '$p_name', '$ii[0]', '$ii[1]')");
      echo mysql_error();
    }
    //break;
  }
  stop_time();
?>