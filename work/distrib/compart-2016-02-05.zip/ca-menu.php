<meta charset=utf-8 />
<link rel="shortcut icon" type="image/x-icon" href="i/ca-favicon.ico">
<?
include "analytics.php";
?>
<? 
  $bname = basename($_SERVER['PHP_SELF'], '.php');
if (!isset($no_title)) { 
  echo "<title>CompArt -  ";
  if ($bname != "index") echo "(". $bname . ")";
  echo "</title>";
} 
?>
<center>
<SCRIPT TYPE='text/javascript' SRC='overlibmws/overlibmws.js'></SCRIPT>
<DIV ID='overDiv' STYLE='position: absolute; visibility: hidden; z-index: 1000;'></DIV>
<center><table border=0>
<tr>
<td>
<font face=arial size=5>
<a href=ca.php><img alt='Compart' align=absmiddle style="vertical-align:middle" border=0 src=images/compart_120.png></a>
<td>
<table width=100%>
<tr>
<td>
<? 
  if ($bname != "graph") {
?>
<td align=right>Share: 
<script type="text/javascript" src="//yastatic.net/share/share.js" charset="utf-8"></script>
<div style='display:inline-block' class="yashare-auto-init" 
data-yashareL10n="en" 
data-yashareType="small" 
data-yashareLink="http://composerquiz.sourceforge.net/ca.php"
data-yashareTitle="CompArt"
data-yashareImage="http://composerquiz.sourceforge.net/images/compart_200.png"
data-yashareQuickServices="vkontakte,facebook,twitter,moimir" 
data-yashareTheme="counter"></div><div style='display:inline-block' class="yashare-auto-init" 
data-yashareL10n="en" 
data-yashareType="none" 
data-yashareLink="http://composerquiz.sourceforge.net/ca.php"
data-yashareTitle="CompArt"
data-yashareImage="http://composerquiz.sourceforge.net/images/compart_200.png"
data-yashareQuickServices="odnoklassniki,lj,gplus"></div>
<?
  } // 
?>
</table>
&nbsp;
<font face=arial size=4>
<a href=ca-input.php>Test</a> |
<a href=ca-slide.php?only_pos=on>Slideshow</a> |
<a href=ca-comp.php>Composers</a> |
<a href=ca-art.php>Artists</a> |
<a href=ca-tracks.php>Tracks</a> |
<a href=ca-log.php>Activity</a> |
<a href=ca-contact.php>Contact</a>
</font>
</td>
<td>
<a href=http://arkhipenko.weebly.com><img height=70 align=absmiddle style="vertical-align:middle" border=0 src=images/amp200.gif></a>
</td>
</tr>
<tr>
<td style="max-width:<?
  if (!isset($page_width)) echo "850px"; 
  else echo "$page_width";
?>;" colspan=3>
<hr>
<?
  //register_shutdown_function('shutdown_function');
?>