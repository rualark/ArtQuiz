<?
  include "qlib.php";
  include "style.php";
  include "ca-menu.php";  
  
?>
<p><b>Compart</b> project is aimed at exploring associations between composers and artists (painters).
<p>Please go to <a href=ca-input.php>Test</a> section to select paintings that best suit the music that you hear.
<p>Explore other menu items to see statistics of associations made by you and other visitors.