<?
  include "qlib.php";
  include "style.php";
  include "ca-menu.php";  

  start_time();
  echo "<b>Latest associations created using Test:</b><br><br>";
  $q = "SELECT c_id, c_name, a_name, l_time, l_id, v_up, v_down, ip
    FROM ca_log 
    LEFT JOIN cc_composers USING (c_id) 
    LEFT JOIN {$adb}artists ON (ca_log.a_id = artists.a_id)
    ORDER BY l_id DESC
    LIMIT 300";
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  echo "<table>";
  for ($i=0; $i<$n; $i++) {
    $w = mysql_fetch_assoc($r);
    $pl_id = $w[l_id]-1;
    echo "<tr>";
    echo "<td>";
    //echo "<a href=http://www.hostip.info><img src='http://api.hostip.info/flag.php?ip=$w[ip]'></a> ";
    if ($w[ip] == get_ip()) echo "<b>";
    echo substr($w[l_time], 0, 16);
    echo "<td><a href=ca-slide.php?l_id=$pl_id><img height=14 src=i/play.gif></a> <a href=am.php?c_id=$w[c_id]>$w[c_name]</a> - ";
    echo "<a href=artist.php?a_id=$w[a_id]><font color=orange>$w[a_name]</font></a>";
    if ($w[v_up]>0) echo " <font color=green><b>$w[v_up]</b></font> <img border=0 height=15 src=images/up-g.png> ";
    if ($w[v_down]>0) echo " <img border=0 height=15 src=images/down-g.png> <font color=red><b>$w[v_down]</b></font> ";
  }
  echo "</table>";
  stop_time();
?>