<?
  include "qlib.php";

  start_time();
  secure_variable("l_id");
  secure_variable("c_id");
  secure_variable("a_id");
  secure_variable("action");
  secure_variable("l_id2");
  secure_variable("v_type");
  secure_variable("only_pos");

  if ($c_id > 0) $cond .= " AND c_id='$c_id' ";
  if ($a_id > 0) $cond .= " AND a_id='$a_id' ";
  
  if ($action == "vote") {
    echo vote_compart($l_id2, $v_type);
    die ("<script language=\"javascript\">location.replace(\"ca-slide.php?l_id=$l_id&a_id=$a_id&c_id=$c_id&only_pos=$only_pos\");</script>"); 
  }
  
  include "style.php";
  include "ca-menu.php";  
  echo "<body onload='window.scroll(0, 145);'>";
  
  echo "<form action=ca-slide.php method=get>";
  echo "<input type=hidden name=c_id value='$c_id'>";
  echo "<input type=hidden name=a_id value='$a_id'>";
  echo "<input type=hidden name=l_id value='$l_id'>";
  echo "<input onChange='this.form.submit();' type=checkbox name=only_pos";
  if ($only_pos=='on') echo ' checked';
  echo "> Show only associations with 70% positive votes or more";
  echo "</form><br>";
  
  if ($l_id == 0) {
    $q = "SELECT MAX(l_id) as mx FROM ca_log";
    $r = mysql_query($q);
    echo mysql_error();
    $w = mysql_fetch_assoc($r);
    $max_l_id = $w[mx];
    $l_id = mt_rand(0, $max_l_id);
  }

  if ($only_pos == 'on') $cond .= " AND v_up>(v_down*2.5) ";
  
  $q = "SELECT * FROM ca_log LEFT JOIN {$adb}artists USING (a_id) WHERE l_id>$l_id $cond LIMIT 1";
  //echo $q;
  $r = mysql_query($q);
  echo mysql_error();
  $n = mysql_numrows($r);
  if ($n == 0) die ("<script language=\"javascript\">location.replace(\"ca-slide.php?l_id=1&a_id=$a_id&c_id=$c_id&only_pos=$only_pos\");</script>"); 
  $w = mysql_fetch_assoc($r);

  load_track($w[t_id]);

  $us[u_oneblock] = 1;
  
  // Load vote
  $v_id = mysql_real_escape_string($_COOKIE["vote_$w[l_id]"]);
  if ($v_id>0) {
    $q = "SELECT * FROM ca_votes WHERE v_id='$v_id'";
    $r = mysql_query($q);
    echo mysql_error();
    $wv = mysql_fetch_assoc($r);
  }

  //$img_url = "$root_art/$w[a_id]/".str_pad($w[p_id], 4, '0', STR_PAD_LEFT).".jpg";
  //echo "<div style='width: 1200px; height: 800px; vertical-align: middle; display: table-cell'>";
  echo "<center><a href=ca-slide.php?l_id=$w[l_id]&a_id=$a_id&c_id=$c_id&only_pos=$only_pos>";
  // style='margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%;' 
  //echo "<img align=top src='$img_url'>";
  show_painting($w[a_id], $w[p_id], 850, 850);
  echo "</a>";
  //echo "</div>";
  echo "<p>";

  if ($w[v_up]>0) echo "<font color=green><b>$w[v_up]</b></font> ";
  $img = "up-g.png";
  if ($wv[v_type]==1) $img="up.png";
  if ($wv[v_type]!=-1) echo "<a title='Vote up' href=# onclick='location.replace(\"ca-slide.php\" + \"?action=vote&l_id=$w[l_id]&l_id2=$w[l_id]&v_type=1&c_id=$c_id&a_id=$a_id&only_pos=$only_pos\")'>";
  echo "<img border=0 height=25 src=images/$img></a> ";
  $img = "down-g.png";
  if ($wv[v_type]==-1) $img="down.png";
  if ($wv[v_type]!=1) echo "<a title='Vote down' href=# onclick='location.replace(\"ca-slide.php\" + \"?action=vote&l_id=$w[l_id]&l_id2=$w[l_id]&v_type=-1&c_id=$c_id&a_id=$a_id&only_pos=$only_pos\")'>";
  echo "<img valign=bottom height=25 src=images/$img></a> ";
  if ($w[v_down]>0) echo "<font color=red><b>$w[v_down]</b></font> ";

  echo "</center>";
  echo "<table width=100%><tr><td valign=top>";
  echo "<a href=artist.php?a_id=$w[a_id]><font size=+2>$w[a_name]</font></a> ".strtoupper(substr($w[a_nation], 0, 3))."-".(substr($w[a_years], 0, 4))." ".$w[a_genre];
  echo " <a target=_blank href='http://images.google.com/searchbyimage?image_url=$img_url'><img height=16 src=images/help.png></a> ";
  
  echo "<td valign=top>";
  echo "<a href=am.php?c_id=$ts[c_id]><font size=+2>$ts[c_name4]</font></a> $ts[c_country] ($ts[c_years]) $ts[p_name]<br><a href=ptracks.php?t_id=$ts[t_id]>";
  if ($ts[t_folder2] != "") echo "$ts[t_folder2]/";
  echo "$ts[t_name]</a> ";
  echo meta_conv($ts[t_meta2]);
  echo "</table><br><br>";
  show_player($ts[t_id], $w[b_id], $us[u_oneblock], $play_symlinks, 1, $w[b_id]);

  //echo "<br><a href=ca-slide.php?l_id=$w[l_id]>NEXT</a>";
  echo "<script>setTimeout(function(){ location = 'ca-slide.php?l_id=$w[l_id]&a_id=$a_id&c_id=$c_id&only_pos=$only_pos'; }, 60000);</script>";
  stop_time();
?>
<script>window.scroll(0, 145);</script>