<?
  //include "ad.php";
?>