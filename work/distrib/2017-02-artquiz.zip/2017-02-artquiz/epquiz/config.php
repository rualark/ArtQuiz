<?
  //$max_year = date("Y")-70;
  //$year_cond = " AND a_year2<$max_year AND a_year2 != 0 ";
?>