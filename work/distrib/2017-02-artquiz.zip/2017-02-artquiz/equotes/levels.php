<?
  include "lib.php";
  $auth_necessary=0;
  include "../auth.php";

  include "style.php";
  include "menu.php";
  
  start_time();
  
  secure_variable("act");
  
  echo "<center>";
  echo "Please select your difficulty level:<br><br><br><br>";
  echo "<font size=+3>";
  echo "<a href=qquiz.php?act=reset&i_id=1&mar=3&mqr=102&an=45&qn=99>Easy</a> - ";
  echo "<a href=qquiz.php?act=reset&i_id=1&mar=3&mqr=123&an=45&qn=1036>Normal</a> - ";
  echo "<a href=qquiz.php?act=reset&i_id=1&mar=4&mqr=111&an=283&qn=3112>Hard</a> - ";
  echo "<a href=qquiz.php?act=reset&i_id=1&mar=101&mqr=108&an=4439&qn=34150>Harder</a> - ";
  echo "<a href=qquiz.php?act=reset&i_id=1&mar=117&mqr=1913&an=24961&qn=527443>Insane</a> ";
  echo "</font>";
  echo "<br><br><br><br>You can also select or create custom difficulty levels (isles) <a href=qi.php>here</a>.";
  echo "<hr></center>";
  
  //stop_time();
?>