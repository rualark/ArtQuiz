<?
  include "alib.php";
  include "style.php";
  
  start_time();
  
  secure_variable("a");
  secure_variable("ac");
  secure_variable("p");
  secure_variable("total");
  secure_variable("correct");
  if (!isset($correct)) $correct = 0;
  if (!isset($total)) $total = 0;
  /*
  secure_variable("a");
  secure_variable("g");
  secure_variable("p");
  echo "/".gzuncompress(base64_decode($a));
  echo "/".gzuncompress(base64_decode($g));
  echo "/".gzuncompress(base64_decode($p));
  */
  
  if (isset($a)) {
    mysql_query("INSERT INTO log VALUES('', '$ac', '$a', '$p', '$_SERVER[REMOTE_ADDR]', NOW(), '$_SERVER[HTTP_USER_AGENT]')");
    echo mysql_error();
  }
  
  // Select ids
  $q = "SELECT a_id FROM artists WHERE a_name!='' AND p_num>2 ORDER BY RAND() LIMIT 4";
  $r = mysql_query($q);
  $a_cnt = mysql_numrows($r);
  for ($i=0; $i<$a_cnt; $i++) {
    $w = mysql_fetch_assoc($r);
    $a_id[$i] = $w[a_id];
    if ($cond != '') $cond .= ",";
    $cond .= $a_id[$i];
  }

  // Select artists sorted
  $q = "SELECT * FROM artists WHERE a_id IN ($cond) ORDER BY a_years";
  //echo $q;
  $r = mysql_query($q);
  $a_cnt = mysql_numrows($r);
  $a_correct = mt_rand(0, $a_cnt-1);
  for ($i=0; $i<$a_cnt; $i++) {
    $aa[$i] = mysql_fetch_assoc($r);
    $p_id[$i] = mt_rand(1, $aa[$i][p_num]);
    for ($x=0; $x<1000; $x++) {
      $p_id2[$i] = mt_rand(1, $aa[$i][p_num]);
      //if (!file_exists(get_purl($aa[$i][a_id], $p_id2[$i]))) continue;
      if ($p_id[$i] != $p_id2[$i]) break;
    }
    for ($x=0; $x<1000; $x++) {
      $p_id3[$i] = mt_rand(1, $aa[$i][p_num]);
      //if (!file_exists(get_purl($aa[$i][a_id], $p_id3[$i]))) continue;
      if (($p_id[$i] != $p_id3[$i]) && ($p_id2[$i] != $p_id3[$i])) break;
    }
  }
  $w = $aa[$a_correct];
  echo "<script>";
  echo "var a_correct = $a_correct;";
  echo "var a_id = '$w[a_id]';";
  echo "var a_name = '$w[a_name]';";
  echo "var a_genre = '$w[a_genre]';";
  echo "var a_nation = '$w[a_nation]';";
  echo "var a_years = '$w[a_years]';";
  echo "var a_link = '$w[a_wiki_en]';";
  echo "</script>";
  
  // Show artists
  echo "<center><table><tr><td>";
  echo "<b>Guess artist.</b>";
  if ($total>0) echo " Total answers: <b>$total</b>. Correct: <b>".round($correct/$total*100)."%</b> <a href=aquiz.php>Reset</a>";
  echo "<center><table><tr>";
  echo "<td><span id=picture>";
  //echo "<a href='javascript:void(0);' onclick=\"check_answer(-1);\");'>";
  echo "<div style='width: 1200px; height: 700px; vertical-align: middle; display: table-cell'>";
  echo "<img align=top style='margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%;' src='".get_purl($aa[$a_correct][a_id], $p_id[$a_correct])."'></div></span>";
  echo "<td><span id=answer>";
  echo "<a target=_blank href='http://images.google.com/searchbyimage?image_url=$root_web/".get_purl($aa[$a_correct][a_id], $p_id[$a_correct])."'>";
  echo "<img valign=bottom height=20 src=i/help.png>";
  echo "</span><td><span id=alternative></span>";
  echo "</table>";
  echo "<table cellspacing=4><tr>";
  for ($i=0; $i<$a_cnt; $i++) {
    // <a href='aquiz.php?g=".base64_encode(gzcompress($aa[$i][a_id]))."&a=".base64_encode(gzcompress($aa[$a_correct][a_id]))."&p=".base64_encode(gzcompress($p_id[$a_correct]))."'>
    echo "<td valign=top bgcolor=#eeeeee><center><a href='javascript:void(0);' onclick=\"check_answer($i, ".$aa[$i][a_id].");\"><font face=arial size=6>".$aa[$i][a_name]."</font></a>";
    echo " <a target=_blank href='".$aa[$i][a_wiki_en]."'><img valign=bottom height=20 src=i/help.png></a>";
    echo "<br><font color=#555555>".strtoupper(substr($aa[$i][a_nation], 0, 3))."-".(substr($aa[$i][a_years], 0, 2)+1)." ".$aa[$i][a_genre]."</font>";
    echo "<br><a href='javascript:void(0);' onclick=\"check_answer($i, ".$aa[$i][a_id].");\"><img width=300 src='".get_purl($aa[$i][a_id], $p_id2[$i])."'></a>";
  }
  echo "</table>";
  echo "</table>";
  //       '<iframe width=800 height=700 src=\"http://en.m.wikipedia.org/w/index.php?search=' + a_name + '\"></iframe>';
?>
<script>
  function check_answer(a1, a1_id) {
    color = '#ffaaaa';
    correct = <?=$correct; ?>;
    if (a1 == a_correct) {
      color = '#aaffaa';
      correct ++;
    }
    document.getElementById('answer').innerHTML = 
      '<table cellpadding=10 width=300 height=700><tr><td bgcolor=' + color + '><center><b>Correct answer:</b><br><br><img width=250 src=\"paintings/' + a_id + '/photo.jpg\"><br><br>Artist: <b>' + a_name + '</b><br>Genre: <b>' + a_genre + 
      '</b><br>Nationality: <b>' + a_nation + '</b><br>Years: <b>' + a_years + '</b><br><br><a target=_blank href=' + a_link + '><img valign=bottom height=20 src=i/help.png></a></table>';
    document.getElementById('picture').innerHTML = 
      '<? echo "<div style=\"width: 400px; height: 700px; vertical-align: middle; display: table-cell\"><a target=_blank href=\"http://images.google.com/searchbyimage?image_url=$root_web/".get_purl($aa[$a_correct][a_id], $p_id[$a_correct])."\"><img align=middle style=\"margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%\" src=\"".get_purl($aa[$a_correct][a_id], $p_id[$a_correct])."\"></div>"; ?>';
    document.getElementById('alternative').innerHTML = 
      '<? echo "<div style=\"width: 400px; height: 700px; vertical-align: middle; display: table-cell\"><center>Bonus picture:<br><img align=middle style=\"margin-top: auto; margin-bottom: auto; margin-left: auto; margin-right: auto; text-align: center; display: block; max-width: 100%; max-height: 100%\" src=\"".get_purl($aa[$a_correct][a_id], $p_id3[$a_correct])."\"></div>"; ?>';
    setTimeout(function(){ location = 'aquiz.php?a=' + a1_id + '&ac=<?=$aa[$a_correct][a_id]?>&p=<?=$p_id[$a_correct]?>&total=<?=($total+1);?>&correct=' + correct; }, 6000);
  }
</script>

<?
  stop_time();
?>