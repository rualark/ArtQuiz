<?
  $os = "win";
mysql_connect("localhost", "user", "pass");
//echo mysql_report_error();
mysql_select_db("aquiz");
//echo mysql_report_error();
?>